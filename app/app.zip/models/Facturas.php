<?php


class Facturas extends Eloquent {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'facturas';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */

	

}