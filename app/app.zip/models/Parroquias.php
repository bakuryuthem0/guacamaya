<?php


class Parroquias extends Eloquent {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'parroquia';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */

	

}