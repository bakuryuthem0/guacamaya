<?php


class Estados extends Eloquent {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'estado';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */

	

}