<?php


class Misc extends Eloquent {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'miscelanias';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */

	

}