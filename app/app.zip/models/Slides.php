<?php


class Slides extends Eloquent {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'slides';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */

	

}