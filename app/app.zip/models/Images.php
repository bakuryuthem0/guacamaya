<?php


class Images extends Eloquent {

}