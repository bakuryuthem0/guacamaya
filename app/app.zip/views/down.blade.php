<html>
	<head>
		<title>Guacamayastores tienda virtual</title>
		<link rel="shortcut icon" href="{{ asset('images/favicon.jpg') }}" />
		<meta name="description" content="tienda virtual en maracay">
		<meta name="keywords" content="publicidad,publicidad online, tienda online, maracay, comprar en maracay, tienda online,tienda virtual">
		
		<style type="text/css">
			body,html
			{
				background-color:rgba(236, 236, 236, 1);
				padding:0px;
				margin:0px;
			}
			#pronto
			{
				width: 100%;
				
				display: block;
				margin: 0 auto;
			}
		</style>
	</head>
	<body>
		<img src="prontog.jpg" id="pronto">
	</body>
	<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
$.src='//v2.zopim.com/?2qPOZqZ2IaypF8Jd7TLchBaYy0CjQwsP';z.t=+new Date;$.
type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->
</html>