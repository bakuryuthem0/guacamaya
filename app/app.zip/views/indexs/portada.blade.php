@extends('layouts.default')

@section('content')

<a href="{{ URL::to('inicio') }}">Ingrear</a>
@stop